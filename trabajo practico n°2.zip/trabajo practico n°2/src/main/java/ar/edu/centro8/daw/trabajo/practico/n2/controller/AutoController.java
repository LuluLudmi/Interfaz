package ar.edu.centro8.daw.trabajo.practico.n2.controller;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.beans.factory.annotation.Autowired;
import ar.edu.centro8.daw.trabajo.practico.n2.model.Auto;
import ar.edu.centro8.daw.trabajo.practico.n2.service.IAutoService;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })

public class AutoController {
@Autowired
    private IAutoService autoServ;

    @GetMapping("/autos/traer")
    public List<Auto> getAutos() {
        return autoServ.getAutos();
    }

    @PostMapping("/autos/crear")
    public String saveAuto(@RequestBody Auto auto) {
        autoServ.save(auto);
        return "El auto fue creado correctamente";
    }

    @DeleteMapping("/autos/borrar/{id}")
    public String deleteAuto(@PathVariable Long id) {
        autoServ.delete(id);
        return "El auto fue eliminado correctamente";
    }

    @PutMapping("/autos/editar/{id}")
    public Auto editAuto(
            @PathVariable Long id,
            @RequestParam(required = false) String marca,
            @RequestParam(required = false) Integer precio) {

        Auto autoActual = autoServ.findById(id);
        if (autoActual != null) {
            // Si algún parámetro es nulo, mantengo el valor original
            String nuevaMarca = (marca != null) ? marca : autoActual.getMarca();
            int nuevoPrecio = (precio != null) ? precio : autoActual.getPrecio();

            autoServ.editAuto(id, nuevaMarca, nuevoPrecio);
            return autoServ.findById(id);
        } else {
            return null; // O lanzar excepción si prefieres
        }
    }
}